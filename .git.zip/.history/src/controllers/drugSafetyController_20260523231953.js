const Patient = require('../models/Patient');
const { runDrugSafetyAgent } = require('../agents/drugSafetyAgent');

// POST /api/drug-safety/check
// Check drug safety for a list of medications (without a specific patient)
const checkDrugSafety = async (req, res, next) => {
  try {
    const { medications, language } = req.body;

    if (!medications || !Array.isArray(medications) || medications.length === 0) {
      const err = new Error('medications array is required');
      err.status = 400;
      return next(err);
    }

    const isValid = medications.every((m) => m.name);
    if (!isValid) {
      const err = new Error('Each medication must have at least a name');
      err.status = 400;
      return next(err);
    }

    const result = await runDrugSafetyAgent({ medications, language });

    if (result.error) {
      return res.status(200).json({
        success: false,
        message: result.message,
        data: result.fallback,
      });
    }

    res.status(200).json({ success: true, data: result.data });

  } catch (err) {
    next(err);
  }
};

// POST /api/drug-safety/check/:patientId
// Check drug safety using the patient's allergies and chronic conditions from DB
const checkDrugSafetyForPatient = async (req, res, next) => {
  try {
    const { medications, language } = req.body;
    const { patientId } = req.params;

    if (!medications || !Array.isArray(medications) || medications.length === 0) {
      const err = new Error('medications array is required');
      err.status = 400;
      return next(err);
    }

    const isValid = medications.every((m) => m.name);
    if (!isValid) {
      const err = new Error('Each medication must have at least a name');
      err.status = 400;
      return next(err);
    }

    // Fetch patient allergies and chronic conditions from DB
    const patient = await Patient.findById(patientId).select('name allergies chronicConditions');
    if (!patient) {
      const err = new Error('Patient not found');
      err.status = 404;
      return next(err);
    }

    const result = await runDrugSafetyAgent({
      medications,
      allergies: patient.allergies || [],
      chronicConditions: patient.chronicConditions || [],
      language,
    });

    if (result.error) {
      return res.status(200).json({
        success: false,
        message: result.message,
        data: result.fallback,
      });
    }

    res.status(200).json({
      success: true,
      patient: { id: patient._id, name: patient.name },
      data: result.data,
    });

  } catch (err) {
    next(err);
  }
};

module.exports = {
  checkDrugSafety,
  checkDrugSafetyForPatient,
};
