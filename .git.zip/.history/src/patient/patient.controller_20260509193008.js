export const getAllPatients = (request,respons ) => {

}