export const getAllPatients = (request,respons ) => {
console.log("Heelo Final Project");

}