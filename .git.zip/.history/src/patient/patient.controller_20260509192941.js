const getAllPatients = (re) => {

}