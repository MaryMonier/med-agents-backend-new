 const getAllPatients = (request,respons ) => {
console.log("Hello Final Project");

}