const getAllPatients = (request,response) => {

}