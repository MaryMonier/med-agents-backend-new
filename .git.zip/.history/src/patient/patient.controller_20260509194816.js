 const getAllPatients = (request,respons ) => {
console.log("Hello Final Project");
}
 const getPatientById = (request,respons ) => {
console.log("Hello Final Project");
}
 const createPatient = شس (request,respons ) => {
console.log("Hello Final Project");
}
 const deletePatient = (request,respons ) => {
console.log("Hello Final Project");
}
 const updatePatient = (request,respons ) => {
console.log("Hello Final Project");
}

module.exports = {
    getAllPatients,
    getPatientById,
    createPatient,
    deletePatient,
    updatePatient,
}