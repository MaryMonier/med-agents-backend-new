const getAllPatients = (request) => {

}