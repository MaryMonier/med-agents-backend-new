const getAllPatients=()=>{

}