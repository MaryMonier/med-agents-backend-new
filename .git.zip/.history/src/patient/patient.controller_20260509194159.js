 const getAllPatients = (request,respons ) => {
console.log("Hello Final Project");
}
 const getPatientById = (request,respons ) => {
console.log("Hello Final Project");
}
 const createPatent = (request,respons ) => {
console.log("Hello Final Project");
}
module.exports = {
    getAllPatients,
    getPatientById,

}