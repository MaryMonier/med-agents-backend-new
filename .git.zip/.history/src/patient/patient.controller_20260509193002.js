const getAllPatients = (request,respons ) => {

}