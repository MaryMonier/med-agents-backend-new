const { response } = require("../app");
const Patient = require("../models/Patient");

const getAllPatients = (request, respons) => {
    console.log("Hello Final Project");
}
const getPatientById = (request, respons) => {
    console.log("Hello Final Project");
}
const createPatient = async (request, respons) => {
    try {
        console.log("Hello Final Project");
        const patienInfo = request.body
        const patient = await Patient.create(patienInfo)
        return response  
    } catch (error) {
        return response.status(500).json({ success: false, message: "internal server error" })
    }



}
const deletePatient = (request, respons) => {
    console.log("Hello Final Project");
}
const updatePatient = (request, respons) => {
    console.log("Hello Final Project");
}

module.exports = {
    getAllPatients,
    getPatientById,
    createPatient,
    deletePatient,
    updatePatient,
}