const getAllPatients = (request,respons e) => {

}