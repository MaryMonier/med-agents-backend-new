const Patient = require("../models/Patient");

 const getAllPatients = (request,respons ) => {
console.log("Hello Final Project");
}
 const getPatientById = (request,respons ) => {
console.log("Hello Final Project");
}
 const createPatient = async (request,respons ) => {
console.log("Hello Final Project");
const pa req.body
const patient = Patient.create()

}
 const deletePatient = (request,respons ) => {
console.log("Hello Final Project");
}
 const updatePatient = (request,respons ) => {
console.log("Hello Final Project");
}

module.exports = {
    getAllPatients,
    getPatientById,
    createPatient,
    deletePatient,
    updatePatient,
}