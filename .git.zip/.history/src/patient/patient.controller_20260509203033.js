const { response } = require("../app");
const Patient = require("../models/Patient");

const getAllPatients = async (request, respons) => {
    try {
        console.log("Hello Final Project");
        const allPatients = await Patient.find()
        return response.status(200).json({ message: true, data: allPatients })
    } catch (error) {
        return response.status(500).json({ success: false, message: "internal server error" })
    }
}
const getPatientById = async (request, respons) => {
    try {
        console.log("Hello Get patient by id");
        const id = request.params.id
        if (!id) {
            return response.status(500).json({ success: false, message: "patient not " })
        }
        const patient = await Patient.findById(id)
        return response.status(200).json({ success: true, data: patient })
    }
    catch (error) {
        return response.status(500).json({ success: false, message: "internal server error" })
    }
}
const createPatient = async (request, respons) => {
    try {
        console.log("Hello From Create patient");
        const patienInfo = request.body
        const patient = await Patient.create(patienInfo)
        return response.status(200).json({ success: true, data: patient })
    } catch (error) {
        return response.status(500).json({ success: false, message: "internal server error" })
    }



}
const deletePatient = async (request, respons) => {
    console.log("Hello Final Project");

}
const updatePatient = async (request, respons) => {
    console.log("Hello Final Project");
}

module.exports = {
    getAllPatients,
    getPatientById,
    createPatient,
    deletePatient,
    updatePatient,
}