const getAllPatients = () => {

}