const getAllPatients=(){

}