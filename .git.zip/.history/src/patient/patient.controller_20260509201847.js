const { response } = require("../app");
const Patient = require("../models/Patient");

const getAllPatients = (request, respons) => {
    console.log("Hello Final Project");
}
const getPatientById =async (request, respons) => {
    try{
        console.log("Hello Get patient by id");
     const id = request.params.id
     const patient = await patient
    }
    catch(error){
return response.status(500).json({ success: false, message: "internal server error" })
    }
}
const createPatient = async (request, respons) => {
    try {
        console.log("Hello From Create patient");
        const patienInfo = request.body
        const patient = await Patient.create(patienInfo)
        return response.status(200).json({success:true,data:patient})  
    } catch (error) {
        return response.status(500).json({ success: false, message: "internal server error" })
    }



}
const deletePatient = (request, respons) => {
    console.log("Hello Final Project");
}
const updatePatient = (request, respons) => {
    console.log("Hello Final Project");
}

module.exports = {
    getAllPatients,
    getPatientById,
    createPatient,
    deletePatient,
    updatePatient,
}