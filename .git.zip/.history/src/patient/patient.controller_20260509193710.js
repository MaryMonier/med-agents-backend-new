export const getAllPatients = (request,respons ) => {
console.log();

}