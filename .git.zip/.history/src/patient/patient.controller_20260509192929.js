const getAllPatients(){
    
}