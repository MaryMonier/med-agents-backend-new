const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const path = require("path");

const connectDB = require("./config/db"); // ⬅️  السطر ده

const errorHandler = require("./middleware/errorHandler");
const patientRouter = require("./routes/patient.router");
const contactRouter = require("./routes/contact.routes");
const authRoutes = require("./routes/auth.routes");
const followupRoutes = require("./routes/followupRoutes");
const prescriptionRoutes = require("./routes/prescriptionRoutes");
const consultationRoutes = require("./routes/consultationRoutes");
const drugSafetyRoutes = require("./routes/drugSafetyRoutes");
const quickDrugCheckRoutes = require("./routes/quickDrugCheckRoutes");
const subscriptionRoutes = require("./routes/subscription.router");
const paymentRoutes = require("./routes/payment.routes");
const followupAgentRouter = require("./routes/followupAgentRoutes");
const app = express();
const medicalAgentRouter = require("./routes/medicalAgentRoutes");
const reportGenRoutes = require("./routes/reportGen.routes");
const dashboardRoutes = require("./routes/dashboardRoutes");

app.set("trust proxy", 1);

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  message: { error: "Too many requests, please try again later." },
});

app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(limiter);

// بيسمح بعرض/تحميل ملفات التحاليل والأشعة المرفوعة من الفرونت (اللي غالبًا
// على دومين مختلف) - helmet افتراضيًا بيحط Cross-Origin-Resource-Policy:
// same-origin وده بيمنع تحميل الصور/الـ PDFs من دومين تاني، فبنستثني
// المسار ده بس
app.use(
  "/uploads",
  (req, res, next) => {
    res.setHeader("Cross-Origin-Resource-Policy", "cross-origin");
    next();
  },
  express.static(path.join(__dirname, "../uploads")),
);

app.use("/api/auth", authRoutes);

app.use("/api/patient", patientRouter);
app.use("/api/followups", followupRoutes);
app.use("/api/prescriptions", prescriptionRoutes);
app.use("/api/patients", patientRouter);
app.use("/api/contact", contactRouter);
app.use("/api/drug-safety", drugSafetyRoutes);

app.use("/api/consultations", consultationRoutes);

app.use("/api/medical-agent", medicalAgentRouter);
app.use("/api/payment", paymentRoutes);
app.use("/api/followup-agent", followupAgentRouter);
app.use("/api/drug-safety", quickDrugCheckRoutes);
app.use("/api/subscription", subscriptionRoutes);
app.get("/", (req, res) => {
  res.json({ message: "Med Agents API is running!" });
});

app.use("/api/reports", reportGenRoutes);
app.use("/api/dashboard", dashboardRoutes);

app.use(errorHandler);

module.exports = app;
