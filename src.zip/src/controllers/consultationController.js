const Consultation = require("../models/Consultation");
const Patient = require("../models/Patient");
const Followup = require("../models/Followup");
const Prescription = require("../models/Prescription");
const fs = require("fs");
const path = require("path");
const { UPLOAD_DIR } = require("../middleware/labFilesUpload.middleware");

const {
  runDifferentialDiagnosisAgent,
} = require("../agents/differentialDiagnosisAgent");
const {
  runMedicationSuggestionAgent,
} = require("../agents/medicationSuggestionAgent");
const {
  getAllActiveMedicationsForPatient,
} = require("./prescriptionController");

// أقصى عدد ملفات بنبعتها فعليًا للإيجنت في الطلب الواحد (حتى لو الكونسلتيشن
// فيها أكتر) - عشان الـ payload المبعوت لـ Gemini يفضل في حجم معقول
const MAX_LAB_FILES_PER_REQUEST = 4;

/**
 * بتاخد ليستة labFiles (زي ما بترجع من endpoint الرفع: [{url, mimeType,
 * originalName}]) وبتقرا كل ملف فعليًا من الديسك وترجعه base64 عشان
 * يتبعت لإيجنت التشخيص التفريقي (Gemini بس هو اللي بيشوفهم فعليًا). أي
 * ملف مش موجود على الديسك أو حصل معاه خطأ في القراية بيتجاهل بصمت بدل ما
 * يوقف الطلب كله.
 */
const readLabFilesAsBase64 = (labFiles = []) => {
  if (!Array.isArray(labFiles) || labFiles.length === 0) return [];

  return labFiles
    .slice(0, MAX_LAB_FILES_PER_REQUEST)
    .map((file) => {
      try {
        const filename = path.basename(file.url || "");
        const fullPath = path.join(UPLOAD_DIR, filename);
        const buffer = fs.readFileSync(fullPath);
        return {
          mimeType: file.mimeType,
          data: buffer.toString("base64"),
          originalName: file.originalName,
        };
      } catch (err) {
        console.error(
          `[readLabFilesAsBase64] Failed to read file ${file?.url}:`,
          err.message,
        );
        return null;
      }
    })
    .filter(Boolean);
};

const getStartOfTodayInEgypt = () => {
  const now = new Date();
  const egyptDateStr = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Africa/Cairo",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(now);
  return new Date(`${egyptDateStr}T00:00:00.000Z`);
};

// لو الدكتور حدد إن الدايجنوزز دي مرض مزمن، نضيفها لـ Patient.chronicConditions
// (من غير تكرار لو هي موجودة بالفعل)
const addDiagnosisToChronicConditions = async (patientId, diagnosis) => {
  if (!diagnosis || !diagnosis.trim()) return;
  const trimmed = diagnosis.trim();
  const normalize = (s) => s.trim().toLowerCase().replace(/\s+/g, " ");
  const normalizedNew = normalize(trimmed);

  const patient = await Patient.findById(patientId).select("chronicConditions");
  if (!patient) return;

  // TEMP DEBUG — هنشيلها بعد ما نلاقي السبب
  console.log(
    `[addDiagnosisToChronicConditions][DEBUG] patientId=${patientId} incoming="${trimmed}" existing=${JSON.stringify(patient.chronicConditions)}`,
  );

  // مش بس exact match — بنشيك كمان لو التشخيص الجديد جزء من حالة مسجلة
  // بالفعل أو العكس (زي "Diabetes" الموجودة و"Type 2 Diabetes" الجديدة)
  // عشان مانضيفش نفس المرض تاني بصياغة مختلفة شوية
  const alreadyExists = (patient.chronicConditions || []).some((c) => {
    const normalizedExisting = normalize(c);
    return (
      normalizedExisting === normalizedNew ||
      normalizedExisting.includes(normalizedNew) ||
      normalizedNew.includes(normalizedExisting)
    );
  });

  // TEMP DEBUG
  console.log(
    `[addDiagnosisToChronicConditions][DEBUG] alreadyExists=${alreadyExists}`,
  );

  if (alreadyExists) return;

  await Patient.findByIdAndUpdate(patientId, {
    $push: { chronicConditions: trimmed },
  });
};

// عكس الدالة اللي فوق: لو الدكتور شال علامة الصح من "Chronic Disease" وهو
// بيعدّل كونسلتيشن كانت متعلّمة كمرض مزمن قبل كده، لازم نشيل التشخيص ده من
// Patient.chronicConditions — بنفس منطق الـ near-duplicate matching عشان
// نلاقي الصيغة الصحيحة المسجلة حتى لو مش مطابقة حرفيًا
const removeDiagnosisFromChronicConditions = async (patientId, diagnosis) => {
  if (!diagnosis || !diagnosis.trim()) return;
  const trimmed = diagnosis.trim();
  const normalize = (s) => s.trim().toLowerCase().replace(/\s+/g, " ");
  const normalizedTarget = normalize(trimmed);

  const patient = await Patient.findById(patientId).select("chronicConditions");
  if (!patient || !Array.isArray(patient.chronicConditions)) return;

  const remaining = patient.chronicConditions.filter((c) => {
    const normalizedExisting = normalize(c);
    const matches =
      normalizedExisting === normalizedTarget ||
      normalizedExisting.includes(normalizedTarget) ||
      normalizedTarget.includes(normalizedExisting);
    return !matches;
  });

  if (remaining.length === patient.chronicConditions.length) return; // مفيش حاجة اتشالت

  await Patient.findByIdAndUpdate(patientId, {
    $set: { chronicConditions: remaining },
  });
};

// بترجّع chronicConditions المحدّثة لبيشنت معيّن — بنستخدمها عشان نبعت
// النسخة النهائية (بعد أي إضافة/إزالة) في الـ response، فالفرونت يقدر
// يعمل dispatch على طول لـ redux (Patient History) من غير ما يستنى refetch
const getChronicConditions = async (patientId) => {
  if (!patientId) return undefined;
  const patient = await Patient.findById(patientId).select("chronicConditions");
  return patient?.chronicConditions;
};

const createConsultation = async (req, res) => {
  try {
    const {
      patientId,
      symptoms,
      diagnosis,
      rawInput,
      language,
      followUpDate,
      followupId,
      isChronic,
      // القيم دي جاية من خطوة "Get AI Recommendation" اللي حصلت قبل كده على
      // طول (مش بنعمل نداء تاني للـ AI هنا) — عشان الحفظ نفسه يشتغل حتى لو
      // مفيش توكينز، ومايبقاش فيه اعتماد على الـ AI في لحظة الحفظ خالص
      structuredNote,
      suggestedSpecialist,
      urgencyLevel,
      // القطع المنظمة الخام لإيجنت التشخيص التفريقي (Differential Diagnosis
      // Agent) - بنحفظهم منفصلين عن structuredNote عشان الـ Patient History
      // يقدر يعرضهم في أقسام منظمة (قراءة سريرية / تشخيص تفريقي / بروتوكول)
      // مش بس نص واحد مجمّع
      clinicalReading,
      possibleDiagnoses,
      // أسماء المصادر الخارجية اللي فعليًا اتستخدمت وقت توليد التشخيص
      // (اختياري - جاي من نتيجة "Get AI Recommendation" زي باقي الحقول دي)
      groundingSourcesUsed,
      // ميتاداتا ملفات التحاليل/الأشعة اللي اترفعت قبل الحفظ (اختياري)
      labFiles,
    } = req.body;

    const patient = await Patient.findById(patientId);
    if (!patient) {
      return res
        .status(404)
        .json({ success: false, message: "Patient not found" });
    }

    // patient.createdBy ممكن يكون null (لو الدكتور الأصلي اتمسح - راجعي
    // الكومنت على الحقل ده في Patient model)، فمينفعش نعمل .toString() عليه
    // مباشرة من غير ما نتأكد إنه موجود الأول، وإلا هيطيح بـ 500
    if (String(patient.createdBy) !== String(req.user.id)) {
      await Patient.findByIdAndUpdate(patientId, {
        $addToSet: { doctors: req.user.id },
      });
    }

    if (followUpDate) {
      const followUp = new Date(followUpDate);
      if (isNaN(followUp.getTime())) {
        return res
          .status(400)
          .json({ success: false, message: "Invalid followUpDate" });
      }
      const today = getStartOfTodayInEgypt();
      const followUpDateOnly = new Date(
        followUp.toISOString().split("T")[0] + "T00:00:00.000Z",
      );
      const todayDateOnly = new Date(
        today.toISOString().split("T")[0] + "T00:00:00.000Z",
      );
      if (followUpDateOnly <= todayDateOnly) {
        return res.status(400).json({
          success: false,
          message: "followUpDate must be after today",
        });
      }
      const maxDate = new Date(todayDateOnly);
      maxDate.setMonth(maxDate.getMonth() + 6);
      if (followUpDateOnly > maxDate) {
        return res.status(400).json({
          success: false,
          message: "followUpDate cannot be more than 6 months from today",
        });
      }
    }

    const consultation = await Consultation.create({
      patientId,
      doctorId: req.user.id,
      symptoms,
      diagnosis,
      rawInput,
      structuredNote: structuredNote || rawInput,
      suggestedSpecialist: suggestedSpecialist || null,
      urgencyLevel: urgencyLevel || "unknown",
      clinicalReading: clinicalReading || null,
      possibleDiagnoses: Array.isArray(possibleDiagnoses)
        ? possibleDiagnoses
        : [],
      groundingSourcesUsed: Array.isArray(groundingSourcesUsed)
        ? groundingSourcesUsed
        : [],
      labFiles: Array.isArray(labFiles) ? labFiles : [],
      isChronic: !!isChronic,
      language: language || "en",
      status: "completed",
      followUpDate: followUpDate || undefined,
      followupId: followupId || null,
    });

    let chronicConditions;
    if (isChronic) {
      await addDiagnosisToChronicConditions(patientId, diagnosis);
      chronicConditions = await getChronicConditions(patientId);
    }

    // لو الكونسلتيشن دي من فولو أب → غير status الفولو أب لـ confirmed،
    // حدّث الـ instructions بالـ structuredNote الجديدة، واربط
    // completionConsultationId بزيارة الإكمال دي (من غير ما نلمس
    // consultationId الأصلية) عشان نقدر نرجع للزيارة الأصلية ولزيارة
    // الإكمال الاتنين وقت اللزوم (تعديل، حذف، عرض تفاصيل)
    if (followupId) {
      await Followup.findByIdAndUpdate(followupId, {
        $set: {
          status: "confirmed",
          instructions: consultation.structuredNote || rawInput,
          completionConsultationId: consultation._id,
          // تاريخ اليوم الفعلي اللي اتكملت فيه الزيارة - مش بنلمس scheduledDate
          // الأصلي خالص عشان يفضل بيمثل الميعاد المجدول زي ما هو
          completedAt: new Date(),
        },
      });
    }

    // لو الدكتور حدد تاريخ فولو أب جديد، اعمل Followup تلقائي
    let newFollowUp = null;
    if (followUpDate) {
      newFollowUp = await Followup.create({
        consultationId: consultation._id,
        patientId,
        doctorId: req.user.id,
        instructions: "-",
        scheduledDate: followUpDate,
        language: language || "en",
      });
    }

    res.status(201).json({
      success: true,
      message: "Consultation created successfully",
      data: consultation,
      chronicConditions,
      newFollowUp,
    });
  } catch (error) {
    res.status(error.isRateLimit ? 429 : 500).json({
      success: false,
      message: error.message,
      isRateLimit: !!error.isRateLimit,
    });
  }
};

const getAllConsultations = async (req, res) => {
  try {
    const consultations = await Consultation.find({})
      .populate("patientId", "name age")
      .populate("doctorId", "name")
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: consultations.length,
      data: consultations,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const getAllConsultationsByDoctor = async (req, res) => {
  try {
    // الأدمن يشوف كونسلتيشنز كل الدكاترة، الدكتور العادي يشوف بتاعته بس
    const isAdmin = req.user.role === "admin";
    const filter = isAdmin ? {} : { doctorId: req.user.id };

    // الكونسلتيشن اللي جاية من فولو أب (followupId موجود) مش بتظهر هنا،
    // دي بتظهر بس في صفحة Follow-ups تحت تاب Completed، وفي Patient History
    const consultations = await Consultation.find({
      ...filter,
      followupId: null,
    })
      .populate("patientId", "name age")
      .populate("doctorId", "name")
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: consultations.length,
      data: consultations,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const getConsultationsByDoctorId = async (req, res) => {
  try {
    const { doctorId } = req.params;

    if (req.user.role !== "admin" && req.user.id !== doctorId) {
      return res.status(403).json({
        success: false,
        message: "Access denied. You can only view your own consultations.",
      });
    }

    const consultations = await Consultation.find({ doctorId })
      .populate("patientId", "name age")
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: consultations.length,
      data: consultations,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const getConsultationById = async (req, res) => {
  try {
    const consultation = await Consultation.findById(req.params.id)
      .populate("patientId", "name age")
      .populate("doctorId", "name");
    if (!consultation) {
      return res
        .status(404)
        .json({ success: false, message: "Consultation not found" });
    }
    if (
      req.user.role !== "admin" &&
      String(consultation.doctorId?._id || consultation.doctorId) !==
        String(req.user.id)
    ) {
      return res.status(403).json({
        success: false,
        message: "Access denied. You can only view your own consultations.",
      });
    }
    res.status(200).json({ success: true, data: consultation });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const updateConsultation = async (req, res) => {
  try {
    console.log(
      `[updateConsultation] id=${req.params.id} payload keys=${Object.keys(req.body).join(",")}`,
    );

    // بنحتاج نعرف حالة isChronic والتشخيص القديمين قبل ما نعمل الـ update،
    // عشان لو الدكتور شال علامة الصح، نعرف نشيل التشخيص الصح (القديم) من
    // chronicConditions — مش التشخيص الجديد اللي ممكن يكون اتغيّر في نفس التعديل
    const beforeUpdate = await Consultation.findById(req.params.id).select(
      "isChronic diagnosis patientId doctorId",
    );
    if (!beforeUpdate) {
      return res
        .status(404)
        .json({ success: false, message: "Consultation not found" });
    }
    if (
      req.user.role !== "admin" &&
      String(beforeUpdate.doctorId) !== String(req.user.id)
    ) {
      return res.status(403).json({
        success: false,
        message: "Access denied. You can only edit your own consultations.",
      });
    }

    // ... باقي الدالة زي ما هي من غير أي تغيير

    // لو followUpDate جاية فاضية (يعني الدكتور مسحها عن قصد)، لازم نحولها
    // لـ null مش نسيبها string فاضي — عشان Mongoose هيفشل وهو بيحاول يحوّلها
    // لـ Date ويرمي CastError
    const updatePayload = { ...req.body };
    if ("followUpDate" in updatePayload && !updatePayload.followUpDate) {
      updatePayload.followUpDate = null;
    }

    const consultation = await Consultation.findByIdAndUpdate(
      req.params.id,
      updatePayload,
      { new: true, runValidators: true },
    );
    if (!consultation) {
      return res
        .status(404)
        .json({ success: false, message: "Consultation not found" });
    }

    console.log(
      `[updateConsultation] saved OK, new diagnosis="${consultation.diagnosis}"`,
    );

    // بنجهّز المتغيّر ده عشان لو فعلاً حصل تغيير (إضافة أو إزالة) في
    // chronicConditions، نبعت النسخة النهائية في الـ response بالظبط زي
    // ما بيحصل في createConsultation — عشان الفرونت يعمل dispatch لـ
    // redux على طول من غير ما يستنى refetch كامل لـ Patient History
    let chronicConditions;
    if ("isChronic" in req.body) {
      if (req.body.isChronic) {
        await addDiagnosisToChronicConditions(
          consultation.patientId,
          req.body.diagnosis ?? consultation.diagnosis,
        );
        chronicConditions = await getChronicConditions(consultation.patientId);
      } else if (beforeUpdate.isChronic) {
        // كانت متعلّمة كمرض مزمن قبل التعديل ودلوقتي اتشالت العلامة — نشيل
        // التشخيص (القديم، قبل أي تعديل عليه في نفس الطلب) من الليستة
        await removeDiagnosisFromChronicConditions(
          beforeUpdate.patientId,
          beforeUpdate.diagnosis,
        );
        chronicConditions = await getChronicConditions(consultation.patientId);
      }
    }

    // لو الدكتور حدد (أو غيّر) تاريخ فولو أب وهو بيعدّل الكونسلتيشن/الفولو
    // أب، لازم نتأكد إن فيه Followup فعلاً بالتاريخ ده — createConsultation
    // بتعمل ده وقت الإنشاء، لكن التعديل مكانش بيعملها خالص، فكان ممكن الدكتور
    // يحدد ميعاد فولو أب وهو بيعدّل ومتتعملش فولو أب فعلية.
    // بنفرّق بين "الحقل مش موجود في الطلب خالص" (تعديل تاني مالوش دعوة
    // بالفولو أب، فمنلمسهاش) و"الحقل موجود لكن فاضي" (الدكتور مسح التاريخ
    // عن قصد، فلازم نلغي أي فولو أب pending كانت متجدولة)
    let newFollowUp = null;
    if ("followUpDate" in req.body) {
      if (req.body.followUpDate) {
        const followUp = new Date(req.body.followUpDate);
        if (Number.isNaN(followUp.getTime())) {
          return res
            .status(400)
            .json({ success: false, message: "Invalid followUpDate" });
        }
        const followUpDateOnly = new Date(
          followUp.getFullYear(),
          followUp.getMonth(),
          followUp.getDate(),
        );
        const today = new Date();
        const todayDateOnly = new Date(
          today.getFullYear(),
          today.getMonth(),
          today.getDate(),
        );
        if (followUpDateOnly <= todayDateOnly) {
          return res.status(400).json({
            success: false,
            message: "followUpDate must be after today",
          });
        }
        const maxDate = new Date(todayDateOnly);
        maxDate.setMonth(maxDate.getMonth() + 6);
        if (followUpDateOnly > maxDate) {
          return res.status(400).json({
            success: false,
            message: "followUpDate cannot be more than 6 months from today",
          });
        }
      }

      const existingPendingFollowup = await Followup.findOne({
        consultationId: consultation._id,
        status: "pending",
      });

      if (req.body.followUpDate) {
        if (existingPendingFollowup) {
          // لو فيه فولو أب pending بالفعل مربوطة بالكونسلتيشن دي، بس حدّث تاريخها
          existingPendingFollowup.scheduledDate = req.body.followUpDate;
          await existingPendingFollowup.save();
          newFollowUp = existingPendingFollowup;
        } else {
          newFollowUp = await Followup.create({
            consultationId: consultation._id,
            patientId: consultation.patientId,
            doctorId: req.user.id,
            instructions: "-",
            scheduledDate: req.body.followUpDate,
            language: consultation.language || "en",
          });
        }
      } else if (existingPendingFollowup) {
        // الدكتور مسح تاريخ الفولو أب عن قصد → نلغي الفولو أب المعلقة دي
        await existingPendingFollowup.deleteOne();
      }
    }

    // لو الكونسلتيشن دي جايه أصلاً من إكمال فولو أب (يعني فيها followupId)،
    // لازم نقفل الفولو أب المصدر دي هنا كمان بالظبط زي ما بيحصل في
    // createConsultation - من قبل كده مكانش بيحصل خالص هنا، فالفرونت كان
    // مضطر يعمل نداء منفصل (updateFollowUp) وبيكتب فوق scheduledDate
    // بالغلط بدل ما يسجل completedAt
    if (req.body.followupId) {
      const sourceFollowup = await Followup.findById(req.body.followupId);
      if (sourceFollowup && !sourceFollowup.completedAt) {
        sourceFollowup.status = "confirmed";
        sourceFollowup.instructions =
          consultation.structuredNote || consultation.rawInput;
        sourceFollowup.completionConsultationId = consultation._id;
        sourceFollowup.completedAt = new Date();
        await sourceFollowup.save();
      }
    }

    res.status(200).json({
      success: true,
      data: consultation,
      chronicConditions,
      newFollowUp,
    });
  } catch (error) {
    console.error("[updateConsultation] FAILED:", error.message);
    res.status(500).json({ success: false, message: error.message });
  }
};

const deleteConsultation = async (req, res) => {
  try {
    const consultation = await Consultation.findById(req.params.id);
    if (!consultation) {
      return res
        .status(404)
        .json({ success: false, message: "Consultation not found" });
    }

    console.log(`[deleteConsultation] deleting id=${consultation._id}`);

    // بنمشي بالظبط على السلسلة المتصلة بالكونسلتيشن اللي هتتمسح، في
    // الاتجاهين:
    // • forward: فولو أبات اتجدولت من الكونسلتيشن دي (consultationId)
    // • backward: فولو أب خلصت (اتكملت) بزيارة هي الكونسلتيشن دي (completionConsultationId)
    // ولو أي فولو أب في السلسلة كانت خلصت بزيارة تانية (كونسلتيشن تانية)،
    // الزيارة دي بتتحسب هي كمان جزء من نفس السلسلة وبتتمسح خالص (مش بس
    // بريسكربتها) — عشان الفولو أب دي أصلاً محفوظة كـ"كونسلتيشن" في
    // الداتا بيز، فمفيش معنى تفضل الكونسلتيشن دي قاعدة من غير الفولو أب
    // اللي بتمثلها، ولا يفضل ظاهر كارت "Follow-up Visit" في الـ Patient
    // History من غير روشتة وراه
    const deadFollowupIds = new Set();
    const deadConsultationIds = new Set([String(consultation._id)]);
    const consultationsToWalk = [String(consultation._id)];
    const visitedConsultations = new Set();

    while (consultationsToWalk.length > 0) {
      const currentId = consultationsToWalk.shift();
      if (visitedConsultations.has(currentId)) continue;
      visitedConsultations.add(currentId);

      const forwardFollowups = await Followup.find({
        consultationId: currentId,
      });
      const backwardFollowups = await Followup.find({
        completionConsultationId: currentId,
      });

      for (const followup of [...forwardFollowups, ...backwardFollowups]) {
        const fid = String(followup._id);
        if (deadFollowupIds.has(fid)) continue;
        deadFollowupIds.add(fid);

        if (followup.completionConsultationId) {
          const compId = String(followup.completionConsultationId);
          deadConsultationIds.add(compId);
          consultationsToWalk.push(compId);
        }
      }
    }

    console.log(
      `[deleteConsultation] chain found: consultations=[${[...deadConsultationIds].join(",")}] followups=[${[...deadFollowupIds].join(",")}]`,
    );

    if (deadConsultationIds.size > 0) {
      await Prescription.deleteMany({
        consultationId: { $in: [...deadConsultationIds] },
      });
    }
    if (deadFollowupIds.size > 0) {
      await Followup.deleteMany({ _id: { $in: [...deadFollowupIds] } });
    }
    await Consultation.deleteMany({
      _id: { $in: [...deadConsultationIds] },
    });

    res.status(200).json({
      success: true,
      message: "Consultation and its full follow-up chain deleted successfully",
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const getAIRecommendation = async (req, res) => {
  try {
    const {
      symptoms,
      diagnosis,
      rawInput,
      language,
      visitType,
      previousDiagnosis,
      previousSymptoms,
      previousInstructions,
      previousPrescription,
      patientId,
      // ميتاداتا ملفات التحاليل/الأشعة المرفوعة قبل الطلب ده: [{url,
      // mimeType, originalName}] - بنقراهم فعليًا من الديسك تحت
      labFiles,
    } = req.body;

    let patientAge = null;
    let patientGender = null;
    let allergies = [];
    let chronicConditions = [];
    let chronicMedications = [];
    if (patientId) {
      const patient = await Patient.findById(patientId).select(
        "dateOfBirth gender allergies chronicConditions chronicMedications",
      );
      if (patient) {
        patientGender = patient.gender || null;
        allergies = patient.allergies || [];
        chronicConditions = patient.chronicConditions || [];
        chronicMedications = patient.chronicMedications || [];
        if (patient.dateOfBirth) {
          const today = new Date();
          const birth = new Date(patient.dateOfBirth);
          patientAge = today.getFullYear() - birth.getFullYear();
          const m = today.getMonth() - birth.getMonth();
          if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) {
            patientAge--;
          }
        }
      }
    }

    const agentResult = await runDifferentialDiagnosisAgent({
      rawInput,
      symptoms,
      diagnosis,
      language: language || "en",
      // لو دي فولو أب، ابعت بيانات الزيارة السابقة عشان الإيجنت يقدر يقارن
      // ويقول هل المريض اتحسن ولا لأ، مش يتعامل معاها كحالة جديدة من الصفر
      isFollowup: visitType === "followup",
      previousDiagnosis: previousDiagnosis || "",
      previousSymptoms: previousSymptoms || "",
      previousInstructions: previousInstructions || "",
      previousPrescription: previousPrescription || "",
      patientAge,
      patientGender,
      allergies,
      chronicConditions,
      chronicMedications,
      // بنقرا الملفات فعليًا من الديسك ونحولها base64 هنا (مش في الإيجنت)
      // عشان الإيجنت يفضل مسؤول بس عن الـ prompt/الـ AI call، والكونترولر
      // هو المسؤول عن أي حاجة فيها I/O (ملفات، داتابيز)
      labFiles: readLabFilesAsBase64(labFiles),
    });

    res.status(200).json({
      success: true,
      data: agentResult,
    });
  } catch (error) {
    res.status(error.isRateLimit ? 429 : 500).json({
      success: false,
      message: error.message,
      isRateLimit: !!error.isRateLimit,
    });
  }
};

const getMedicationSuggestions = async (req, res) => {
  try {
    const {
      diagnosis,
      symptoms,
      rawInput,
      language,
      patientId,
      isFollowup,
      previousPrescription,
    } = req.body;

    if (!diagnosis || !diagnosis.trim()) {
      return res.status(400).json({
        success: false,
        message: "diagnosis is required",
      });
    }

    let allergies = [];
    let activeMedications = [];
    let patientAge = null;
    let recentlyPrescribedForSameDiagnosis = [];

    if (patientId) {
      const patient = await Patient.findById(patientId).select(
        "allergies dateOfBirth",
      );
      if (patient) {
        allergies = patient.allergies || [];
        if (patient.dateOfBirth) {
          const today = new Date();
          const birth = new Date(patient.dateOfBirth);
          patientAge = today.getFullYear() - birth.getFullYear();
          const m = today.getMonth() - birth.getMonth();
          if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) {
            patientAge--;
          }
        }
      }
      activeMedications = await getAllActiveMedicationsForPatient(patientId);

      // عشان التنوع: بندور على زيارات سابقة لنفس المريض بنفس التشخيص
      // (تطابق نص كامل، case-insensitive) مش الفولو أب الحالي، ونجمع أسماء
      // الأدوية اللي اتوصفت فيها - عشان الإيجنت يعرف مايكررش نفس الاختيار
      // كل مرة من غير داعي طبي
      if (!isFollowup) {
        const pastConsultations = await Consultation.find({
          patientId,
          diagnosis: { $regex: `^${diagnosis.trim()}$`, $options: "i" },
        })
          .select("_id")
          .limit(10);

        if (pastConsultations.length > 0) {
          const pastPrescriptions = await Prescription.find({
            consultationId: { $in: pastConsultations.map((c) => c._id) },
          }).select("medications");

          const names = new Set();
          pastPrescriptions.forEach((presc) => {
            presc.medications.forEach((m) => {
              if (m.name) names.add(m.name);
            });
          });
          recentlyPrescribedForSameDiagnosis = [...names];
        }
      }
    }

    const result = await runMedicationSuggestionAgent({
      diagnosis,
      symptoms: symptoms || [],
      rawInput: rawInput || "",
      allergies,
      activeMedications,
      patientAge,
      language: language || "en",
      isFollowup: !!isFollowup,
      previousPrescription: previousPrescription || [],
      recentlyPrescribedForSameDiagnosis,
    });

    if (!result.success) {
      return res.status(502).json({ success: false, message: result.message });
    }

    res.status(200).json({ success: true, data: result.data });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = {
  createConsultation,
  getAllConsultations,
  getConsultationById,
  updateConsultation,
  deleteConsultation,
  getAllConsultationsByDoctor,
  getConsultationsByDoctorId,
  getAIRecommendation,
  getMedicationSuggestions,
};