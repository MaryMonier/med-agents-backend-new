const mongoose = require("mongoose");

const consultationSchema = new mongoose.Schema(
  {
    patientId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Patient",
      required: true,
    },
    doctorId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    symptoms: [{ type: String }],
    diagnosis: { type: String },
    rawInput: { type: String, required: true },
    structuredNote: { type: String },
    urgencyLevel: {
  type: String,
  enum: ["low", "medium", "critical", "unknown"],

    },
    suggestedSpecialist: { type: String },
    status: {
      type: String,
      enum: ["pending", "completed"],
      default: "pending",
    },
    language: { type: String, enum: ["en", "ar"], default: "en" },
    followUpDate: { type: Date },
    // لو الكونسلتيشن دي جاية من فولو أب، بنحفظ الـ id بتاعه هنا
    followupId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Followup",
      default: null,
    },
  },
  { timestamps: true },
);

module.exports = mongoose.model("Consultation", consultationSchema);
